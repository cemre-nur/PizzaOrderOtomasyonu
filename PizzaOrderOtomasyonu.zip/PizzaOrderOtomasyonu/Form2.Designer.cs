﻿namespace Pizza_Order_Otomasyon
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            büyük = new CheckBox();
            orta = new CheckBox();
            küçük = new CheckBox();
            adetpizza = new NumericUpDown();
            adetiçecek = new NumericUpDown();
            label10 = new Label();
            label9 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            ekstra = new ComboBox();
            içecek = new ComboBox();
            pizza = new ComboBox();
            groupBox2 = new GroupBox();
            text_adres = new TextBox();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            text_no = new TextBox();
            text_soyad = new TextBox();
            text_ad = new TextBox();
            groupBox3 = new GroupBox();
            listBox2 = new ListBox();
            list_top = new ListBox();
            label11 = new Label();
            listBox1 = new ListBox();
            btn_temizle = new Button();
            btn_sipariş = new Button();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)adetpizza).BeginInit();
            ((System.ComponentModel.ISupportInitialize)adetiçecek).BeginInit();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(büyük);
            groupBox1.Controls.Add(orta);
            groupBox1.Controls.Add(küçük);
            groupBox1.Controls.Add(adetpizza);
            groupBox1.Controls.Add(adetiçecek);
            groupBox1.Controls.Add(label10);
            groupBox1.Controls.Add(label9);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(ekstra);
            groupBox1.Controls.Add(içecek);
            groupBox1.Controls.Add(pizza);
            groupBox1.Font = new Font("Stencil", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            groupBox1.Location = new Point(15, 11);
            groupBox1.Margin = new Padding(4, 3, 4, 3);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new Padding(4, 3, 4, 3);
            groupBox1.Size = new Size(858, 369);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "ÜRÜNLER";
            // 
            // büyük
            // 
            büyük.AutoSize = true;
            büyük.Font = new Font("Sitka Banner", 10.1999989F, FontStyle.Regular, GraphicsUnit.Point);
            büyük.Location = new Point(47, 181);
            büyük.Name = "büyük";
            büyük.Size = new Size(53, 28);
            büyük.TabIndex = 18;
            büyük.Text = "Big";
            büyük.UseVisualStyleBackColor = true;
            // 
            // orta
            // 
            orta.AutoSize = true;
            orta.Font = new Font("Sitka Banner", 10.1999989F, FontStyle.Regular, GraphicsUnit.Point);
            orta.Location = new Point(47, 159);
            orta.Name = "orta";
            orta.Size = new Size(85, 28);
            orta.TabIndex = 17;
            orta.Text = "Medium";
            orta.UseVisualStyleBackColor = true;
            // 
            // küçük
            // 
            küçük.AutoSize = true;
            küçük.Font = new Font("Sitka Banner", 10.1999989F, FontStyle.Regular, GraphicsUnit.Point);
            küçük.Location = new Point(47, 133);
            küçük.Name = "küçük";
            küçük.Size = new Size(68, 28);
            küçük.TabIndex = 16;
            küçük.Text = "Small";
            küçük.UseVisualStyleBackColor = true;
            // 
            // adetpizza
            // 
            adetpizza.Font = new Font("Sitka Banner", 10.1999989F, FontStyle.Regular, GraphicsUnit.Point);
            adetpizza.Location = new Point(47, 243);
            adetpizza.Name = "adetpizza";
            adetpizza.Size = new Size(89, 29);
            adetpizza.TabIndex = 14;
            // 
            // adetiçecek
            // 
            adetiçecek.Font = new Font("Sitka Banner", 10.1999989F, FontStyle.Regular, GraphicsUnit.Point);
            adetiçecek.Location = new Point(352, 126);
            adetiçecek.Name = "adetiçecek";
            adetiçecek.Size = new Size(89, 29);
            adetiçecek.TabIndex = 13;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Sitka Banner", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label10.Location = new Point(52, 212);
            label10.Margin = new Padding(4, 0, 4, 0);
            label10.Name = "label10";
            label10.Size = new Size(50, 29);
            label10.TabIndex = 11;
            label10.Text = "Adet";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Sitka Banner", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label9.Location = new Point(352, 101);
            label9.Margin = new Padding(4, 0, 4, 0);
            label9.Name = "label9";
            label9.Size = new Size(50, 29);
            label9.TabIndex = 10;
            label9.Text = "Adet";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Sitka Banner", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label4.Location = new Point(52, 101);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(63, 29);
            label4.TabIndex = 6;
            label4.Text = "Boyut";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Sitka Banner", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label3.Location = new Point(656, 41);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(125, 29);
            label3.TabIndex = 5;
            label3.Text = "EK ÜRÜNLER";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Sitka Banner", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label2.Location = new Point(352, 41);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(108, 29);
            label2.TabIndex = 4;
            label2.Text = "İÇECEKLER";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Sitka Banner", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label1.Location = new Point(52, 41);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(98, 29);
            label1.TabIndex = 3;
            label1.Text = "PİZZALAR";
            // 
            // ekstra
            // 
            ekstra.Font = new Font("Sitka Banner", 10.1999989F, FontStyle.Regular, GraphicsUnit.Point);
            ekstra.FormattingEnabled = true;
            ekstra.Items.AddRange(new object[] { "Soğan Halkası", "Çıtır Patates", "Çıtır Tavuk Topları" });
            ekstra.Location = new Point(656, 70);
            ekstra.Margin = new Padding(4, 3, 4, 3);
            ekstra.Name = "ekstra";
            ekstra.Size = new Size(188, 32);
            ekstra.TabIndex = 2;
            // 
            // içecek
            // 
            içecek.Font = new Font("Sitka Banner", 10.1999989F, FontStyle.Regular, GraphicsUnit.Point);
            içecek.FormattingEnabled = true;
            içecek.Items.AddRange(new object[] { "Coca Cola(250 ml)", "Coca Cola(1 Lt)", "Şekersiz Cola Cola(250 ml)", "Fanta(250 ml)", "Fanta(1 Lt)", "Sprite(250 ml)", "Sprite(1 Lt)", "FuseTea Şeftali(250 ml)", "FuseTea Şeftali(1 Lt)", "FuseTea Limon(250 ml)", "FuseTea Limon(1 Lt)", "Cappy Şeftali(250 ml)", "Cappy Karışık(250 ml)", "Cappy Vişne(250 ml)", "Ayran(200 ml)", "Ayran(300 ml)", "Ayran(1 Lt)", "Su(500 ml)" });
            içecek.Location = new Point(352, 70);
            içecek.Margin = new Padding(4, 3, 4, 3);
            içecek.Name = "içecek";
            içecek.Size = new Size(188, 32);
            içecek.TabIndex = 1;
            // 
            // pizza
            // 
            pizza.Font = new Font("Sitka Banner", 10.1999989F, FontStyle.Regular, GraphicsUnit.Point);
            pizza.FormattingEnabled = true;
            pizza.Items.AddRange(new object[] { "Bol Malzemos", "Sucuk Sever", "Mantar Sever", "Sosis Sever", "Karışık", "Pastırma ve Sucuk", "Dört Peynirli", "Tavuklu", "Ballı Hardallı Tavuklu" });
            pizza.Location = new Point(52, 70);
            pizza.Margin = new Padding(4, 3, 4, 3);
            pizza.Name = "pizza";
            pizza.Size = new Size(188, 32);
            pizza.TabIndex = 0;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(text_adres);
            groupBox2.Controls.Add(label8);
            groupBox2.Controls.Add(label7);
            groupBox2.Controls.Add(label6);
            groupBox2.Controls.Add(label5);
            groupBox2.Controls.Add(text_no);
            groupBox2.Controls.Add(text_soyad);
            groupBox2.Controls.Add(text_ad);
            groupBox2.Font = new Font("Stencil", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            groupBox2.Location = new Point(15, 385);
            groupBox2.Margin = new Padding(4, 3, 4, 3);
            groupBox2.Name = "groupBox2";
            groupBox2.Padding = new Padding(4, 3, 4, 3);
            groupBox2.Size = new Size(858, 253);
            groupBox2.TabIndex = 1;
            groupBox2.TabStop = false;
            groupBox2.Text = "MÜSTERI BILGILERI";
            // 
            // text_adres
            // 
            text_adres.Font = new Font("Sitka Banner", 10.1999989F, FontStyle.Regular, GraphicsUnit.Point);
            text_adres.Location = new Point(502, 37);
            text_adres.Margin = new Padding(4, 3, 4, 3);
            text_adres.Multiline = true;
            text_adres.Name = "text_adres";
            text_adres.Size = new Size(326, 141);
            text_adres.TabIndex = 15;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Sitka Banner", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label8.Location = new Point(417, 37);
            label8.Margin = new Padding(4, 0, 4, 0);
            label8.Name = "label8";
            label8.Size = new Size(77, 29);
            label8.TabIndex = 6;
            label8.Text = "ADRES:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Sitka Banner", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label7.Location = new Point(47, 149);
            label7.Margin = new Padding(4, 0, 4, 0);
            label7.Name = "label7";
            label7.Size = new Size(105, 29);
            label7.TabIndex = 5;
            label7.Text = "Telefon No:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Sitka Banner", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label6.Location = new Point(52, 97);
            label6.Margin = new Padding(4, 0, 4, 0);
            label6.Name = "label6";
            label6.Size = new Size(69, 29);
            label6.TabIndex = 4;
            label6.Text = "Soyad:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Sitka Banner", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label5.Location = new Point(52, 38);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(41, 29);
            label5.TabIndex = 3;
            label5.Text = "Ad:";
            // 
            // text_no
            // 
            text_no.Font = new Font("Sitka Banner", 10.1999989F, FontStyle.Regular, GraphicsUnit.Point);
            text_no.Location = new Point(160, 149);
            text_no.Margin = new Padding(4, 3, 4, 3);
            text_no.Name = "text_no";
            text_no.Size = new Size(180, 29);
            text_no.TabIndex = 2;
            // 
            // text_soyad
            // 
            text_soyad.Font = new Font("Sitka Banner", 10.1999989F, FontStyle.Regular, GraphicsUnit.Point);
            text_soyad.Location = new Point(160, 98);
            text_soyad.Margin = new Padding(4, 3, 4, 3);
            text_soyad.Name = "text_soyad";
            text_soyad.Size = new Size(180, 29);
            text_soyad.TabIndex = 1;
            // 
            // text_ad
            // 
            text_ad.Font = new Font("Sitka Banner", 10.1999989F, FontStyle.Regular, GraphicsUnit.Point);
            text_ad.Location = new Point(160, 38);
            text_ad.Margin = new Padding(4, 3, 4, 3);
            text_ad.Name = "text_ad";
            text_ad.Size = new Size(180, 29);
            text_ad.TabIndex = 0;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(listBox2);
            groupBox3.Controls.Add(list_top);
            groupBox3.Controls.Add(label11);
            groupBox3.Controls.Add(listBox1);
            groupBox3.Controls.Add(btn_temizle);
            groupBox3.Controls.Add(btn_sipariş);
            groupBox3.Font = new Font("Stencil", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            groupBox3.Location = new Point(892, 11);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(458, 627);
            groupBox3.TabIndex = 2;
            groupBox3.TabStop = false;
            groupBox3.Text = "Siparis";
            // 
            // listBox2
            // 
            listBox2.Font = new Font("Sitka Banner", 10.1999989F, FontStyle.Regular, GraphicsUnit.Point);
            listBox2.FormattingEnabled = true;
            listBox2.ItemHeight = 24;
            listBox2.Location = new Point(38, 181);
            listBox2.Name = "listBox2";
            listBox2.Size = new Size(388, 148);
            listBox2.TabIndex = 5;
            // 
            // list_top
            // 
            list_top.Font = new Font("Sitka Banner", 10.1999989F, FontStyle.Regular, GraphicsUnit.Point);
            list_top.FormattingEnabled = true;
            list_top.ItemHeight = 24;
            list_top.Location = new Point(150, 388);
            list_top.Name = "list_top";
            list_top.Size = new Size(172, 52);
            list_top.TabIndex = 4;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Stencil", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label11.Location = new Point(150, 361);
            label11.Name = "label11";
            label11.Size = new Size(156, 24);
            label11.TabIndex = 3;
            label11.Text = "Toplam Ücret";
            // 
            // listBox1
            // 
            listBox1.Font = new Font("Sitka Banner", 10.1999989F, FontStyle.Regular, GraphicsUnit.Point);
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 24;
            listBox1.Location = new Point(38, 27);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(388, 148);
            listBox1.TabIndex = 2;
            // 
            // btn_temizle
            // 
            btn_temizle.Location = new Point(296, 462);
            btn_temizle.Name = "btn_temizle";
            btn_temizle.Size = new Size(130, 90);
            btn_temizle.TabIndex = 1;
            btn_temizle.Text = "Temizle";
            btn_temizle.UseVisualStyleBackColor = true;
            btn_temizle.Click += btn_temizle_Click;
            // 
            // btn_sipariş
            // 
            btn_sipariş.Location = new Point(38, 462);
            btn_sipariş.Name = "btn_sipariş";
            btn_sipariş.Size = new Size(130, 90);
            btn_sipariş.TabIndex = 0;
            btn_sipariş.Text = "Siparisi Olustur";
            btn_sipariş.UseVisualStyleBackColor = true;
            btn_sipariş.Click += button1_Click;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(10F, 18F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Tan;
            ClientSize = new Size(1371, 670);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Font = new Font("Showcard Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point);
            Margin = new Padding(4, 3, 4, 3);
            Name = "Form2";
            Text = "CG PİZZA";
            FormClosed += Form2_FormClosed;
            Load += Form2_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)adetpizza).EndInit();
            ((System.ComponentModel.ISupportInitialize)adetiçecek).EndInit();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        public GroupBox groupBox1;
        public Label label2;
        public Label label1;
        public ComboBox ekstra;
        public ComboBox içecek;
        public ComboBox pizza;
        public Label label3;
        public GroupBox groupBox2;
        public Label label4;
        public Label label7;
        public Label label6;
        public Label label5;
        public TextBox text_no;
        public TextBox text_soyad;
        public TextBox text_ad;
        private NumericUpDown adetpizza;
        private NumericUpDown adetiçecek;
        public Label label10;
        public Label label9;
        private TextBox text_adres;
        private Label label8;
        private GroupBox groupBox3;
        private Button btn_temizle;
        private Button btn_sipariş;
        private ListBox list_top;
        private Label label11;
        private ListBox listBox1;
        private ListBox listBox2;
        private CheckBox büyük;
        private CheckBox orta;
        private CheckBox küçük;
    }
}