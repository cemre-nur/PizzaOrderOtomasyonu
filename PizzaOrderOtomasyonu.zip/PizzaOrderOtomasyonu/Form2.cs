﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pizza_Order_Otomasyon
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            decimal ucret = 0;
            //TÜR
            if (pizza.Text == "Bol Malzemos")
            {
                ucret = adetpizza.Value * 120;
            }
            else if (pizza.Text == "Pastırma ve Sucuk")
            {
                ucret = adetpizza.Value * 120;
            }
            else if (pizza.Text == "Tavuklu")
            {
                ucret = adetpizza.Value * 120;
            }
            else if (pizza.Text == "Sucuk Sever")
            {
                ucret = adetpizza.Value * 90;
            }
            else if (pizza.Text == "Mantar Sever")
            {
                ucret = adetpizza.Value * 90;
            }
            else if (pizza.Text == "Sosis Sever")
            {
                ucret = adetpizza.Value * 90;
            }
            else if (pizza.Text == "Karışık")
            {
                ucret = adetpizza.Value * 90;
            }
            else if (pizza.Text == "Ballı Hardallı Tavuklu")
            {
                ucret = adetpizza.Value * 100;
            }
            else if (pizza.Text == " ")
                ucret = adetpizza.Value * 0;

            //BOYUT
            decimal ucret2 = 0;
            if (küçük.Checked == true)
            {
                ucret += ucret2 + 0;
            }
            else if (orta.Checked == true)
            {
                ucret += ucret2 + 10;
            }
            else if (büyük.Checked == true)
            {
                ucret += ucret2 + 20;
            }
            else if (küçük.Checked == false || orta.Checked == false || büyük.Checked == false)
            {
                ucret += ucret2 * 0;
            }

            //İÇECEK
            decimal ucret3 = 0;
            if (içecek.Text == "Coca-Cola(1 Lt)")
            {
                ucret += ucret3 + adetiçecek.Value * 25;
            }
            else if (içecek.Text == "Fanta(1 Lt)")
            {
                ucret += ucret3 + adetiçecek.Value * 25;
            }
            else if (içecek.Text == "Sprite(1 Lt)")
            {
                ucret += ucret3 + adetiçecek.Value * 25;
            }
            else if (içecek.Text == "FuseTea Şeftali(1 Lt)")
            {
                ucret += ucret3 + adetiçecek.Value * 25;
            }
            else if (içecek.Text == "FuseTea Limon(1 Lt)")
            {
                ucret += ucret3 + adetiçecek.Value * 25;
            }
            else if (içecek.Text == "Ayran(1 Lt)")
            {
                ucret += ucret3 + adetiçecek.Value * 25;
            }
            else if (içecek.Text == "Ayran(200 ml)")
            {
                ucret += ucret3 + adetiçecek.Value * 9;
            }
            else if (içecek.Text == "Ayran(300 ml)")
            {
                ucret += ucret3 + adetiçecek.Value * 11;
            }
            else if (içecek.Text == "Su(500 ml)")
            {
                ucret += ucret3 + adetiçecek.Value * 5;
            }
            else if (içecek.Text == "Coca Cola(250 ml)")
            {
                ucret += ucret3 + adetiçecek.Value * 15;
            }
            else if (içecek.Text == "Fanta(250 ml)")
            {
                ucret += ucret3 + adetiçecek.Value * 15;
            }
            else if (içecek.Text == "Sprite(250ml)")
            {
                ucret += ucret3 + adetiçecek.Value * 15;
            }
            else if (içecek.Text == "FuseTea Şeftali(250 ml)")
            {
                ucret += ucret3 + adetiçecek.Value * 15;
            }
            else if (içecek.Text == "FuseTea Limon(250 ml)")
            {
                ucret += ucret3 + adetiçecek.Value * 15;
            }
            else if (içecek.Text == "Cappy Şeftali(250 ml)")
            {
                ucret += ucret3 + adetiçecek.Value * 12;
            }
            else if (içecek.Text == "Cappy Karışık(250 ml)")
            {
                ucret += ucret3 + adetiçecek.Value * 12;
            }
            else if (içecek.Text == "Cappy Vişne(250 ml)")
            {
                ucret += ucret3 + adetiçecek.Value * 12;
            }
            else if (içecek.Text == " ")
            {
                ucret += ucret3 + adetiçecek.Value * 0;
            }

            //EKSTRA
            decimal ucret4 = 0;
            if (ekstra.Text == "Soğan Halkası")
            {
                ucret += ucret4 + 30;
            }
            if (ekstra.Text == "Çıtır Tavuk Topları")
            {
                ucret += ucret4 + 30;
            }
            else if (ekstra.Text == "Çıtır Patates")
            {
                ucret += ucret4 + 25;
            }
            else if (ekstra.Text == " ")
            {
                ucret += ucret4 * 0;
            }

            listBox1.Items.Add(text_ad.Text);
            listBox1.Items.Add(text_soyad.Text);
            listBox1.Items.Add(text_no.Text);
            listBox1.Items.Add(text_adres.Text);

            listBox2.Items.Add(adetpizza.Value + " " + "adet" + " " + pizza.Text);
            listBox2.Items.Add(adetiçecek.Value + " " + "adet" + " " + içecek.Text);
            listBox2.Items.Add(ekstra.Text);

            list_top.Items.Add(ucret + "TL");



        }

        private void btn_temizle_Click(object sender, EventArgs e)
        {
            pizza.Text = " ";
            içecek.Text = " ";
            ekstra.Text = " ";

            küçük.Checked = false;
            orta.Checked = false;
            büyük.Checked = false;

            adetiçecek.Value = 0;
            adetpizza.Value = 0;

            text_ad.Clear();
            text_soyad.Clear();
            text_adres.Clear();
            text_no.Clear();
            listBox1.Items.Clear();
            listBox2.Items.Clear();
            list_top.Items.Clear();


        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
    }
}
